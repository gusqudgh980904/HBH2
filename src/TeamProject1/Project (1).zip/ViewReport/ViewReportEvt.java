package project;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class ViewReportEvt implements ActionListener{

	private ViewReport vr;
	
	public ViewReportEvt(ViewReport vr) {
		this.vr = vr;
		
		
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		
	}

	
	
	
}
